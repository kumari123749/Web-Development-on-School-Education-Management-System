<html>
<body>
<?php
$n = $_POST['first_name'];
$password = $_POST['password'];

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "school";
	
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);
	
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO faclog VALUES ('$n', '$password')";

if ($conn->query($sql) === TRUE) {
   echo "New record created successfully";
   echo '<a href="http://localhost:8012/basic/Education-Management-system-master/teacher1.html">Click here</a>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}