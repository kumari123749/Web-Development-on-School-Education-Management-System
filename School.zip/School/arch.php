<html>
<body>
<?php
$n = $_POST['name'];
$fn = $_POST['father_name'];
$id = $_POST['id'];
$add = $_POST['address'];
$jn = $_POST['join_year'];
$gn = $_POST['graduation_year'];
$gender = $_POST['gender'];
$state = $_POST['state'];
$city = $_POST['city'];
$birth = $_POST['birth_date'];
$pincode = $_POST['pincode'];
$course = $_POST['course'];
$email = $_POST['email'];

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "school";
	
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);
	
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO department VALUES ('$n', '$fn', '$id', '$add', '$jn', '$gn', '$gender', '$state', '$city', '$birth', '$pincode', '$course', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>
</body>
</html>