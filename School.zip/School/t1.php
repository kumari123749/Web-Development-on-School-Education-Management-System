<html>
<body>
<?php
$fn = $_POST['First_name'];
$ln = $_POST['Last_name'];
$birth = $_POST['Birthday_Day'];
$bm = $_POST['Birthday_Month'];
$by = $_POST['Birthday_Year'];
$email = $_POST['Email_Id'];
$Phone = $_POST['Mobile_Number'];
$gender = $_POST['Gender'];
$genderf = $_POST['female'];
$add = $_POST['Address'];
$city = $_POST['City'];
$pincode = $_POST['Pin_Code];