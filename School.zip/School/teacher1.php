<html>
<body>
<?php
$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$birth = $_POST['DateofBirth'];
$email_id = $_POST['EmailId'];
$Phone = $_POST['Mobile_Number'];
$Gender = $_POST['Gender'];
$add = $_POST['Address'];
$city = $_POST['City'];
$pin = $_POST['Pin_Code'];
$state = $_POST['State'];
$country = $_POST['Country'];
$exp = $_POST['Exp'];
$xb = $_POST['ClassX_Board'];
$xp = $_POST['ClassX_Percentage'];
$xy = $_POST['ClassX_YrOfPassing'];
$xiib = $_POST['ClassXII_Board'];
$xiip = $_POST['ClassXII_Percentage'];
$xiiy = $_POST['ClassXII_YrOfPassing'];
$gb = $_POST['Graduation_Board'];
$gp = $_POST['Graduation_Percentage'];
$gy = $_POST['Graduation_YrOfPassing'];
$mb = $_POST['Masters_Board'];
$mp = $_POST['Masters_Percentage'];
$my = $_POST['Masters_YrOfPassing'];
$department = $_POST['department'];

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "school";
	
	
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);
	
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO faculty VALUES ('$FirstName', '$LastName', '$birth', '$email_id', '$Phone', '$Gender', '$add', '$city', '$pin', '$state', '$country', '$exp', '$xb', '$xp', '$xy', '$xiib', '$xiip', '$xiiy', '$gb', '$gp', '$gy', '$mb', '$mp', '$my', '$department')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

?>
</body>
</html>