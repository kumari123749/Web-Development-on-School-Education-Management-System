<html>
<body>
<?php
$fn = $_POST['First_name'];
$ln = $_POST['Last_name'];
$birth = $_POST['Birthday_Day'];
$bm = $_POST['Birthday_Month'];
$by = $_POST['Birthday_Year'];
$email = $_POST['Email_Id'];
$Phone = $_POST['Mobile_Number'];
$gender = $_POST['Gender'];
$genderf = $_POST['female'];
$add = $_POST['Address'];
$city = $_POST['City'];
$pincode = $_POST['Pin_Code];
$state = $_POST['State'];
$country = $_POST['Country'];
$exp = $_POST['Exp'];
$qu1 = $_POST['ClassX_Board'];
$qu2 = $_POST['ClassXII_Percentage'];
$qu3 = $_POST['ClassXII_YrOfPassing']
$qu4 = $_POST['Graduation_Board'];
$qu5 = $_POST['Graduation_Percentage'];
$qu6 = $_POST['Graduation_YrOfPassing'];
$qu7 = $_POST['Masters_Board'];
$qu5 = $_POST['Masters_Percentage'];
$qu6 = $_POST['Masters_YrOfPassing'];
$tech = $_POST['Tech'];
$mana = $_POST['Mana'];
$sci = $_POST['Science'];
$phar = $_POST['Pharmacy'];
$arch = $_POST['Arch'];
$law = $_POST['Law'];
$medi = $_POST['Medi'];

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "school";
	
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);
	
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO faculty VALUES ('$fn', '$ln', '$birth', '$bm', '$by', '$email', '$Phone', '$gender', '$genderf', '$add', '$city', '$pincode', '$state',
'$country', '$exp', '$qu1', '$qu2', '$qu3', '$qu4', '$qu5', '$qu6', '$tech', '$mana', '$sci', '$phar', '$arch', '$law', '$medi')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>
</body>
</html>



