<html>
<body>
<?php
$fn = $_POST['first_name'];
$ln = $_POST['last_name'];
$birth = $_POST['birth_date'];
$Gender = $_POST['Gender'];
$email = $_POST['email'];
$Phone = $_POST['phone'];
$add = $_POST['Address'];
$city = $_POST['city'];
$course = $_POST['subject'];

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "school";
	
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);
	
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO student VALUES ('$fn', '$ln', '$birth', '$Gender', '$email', '$Phone', '$add', '$city', '$course')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>
</body>
</html>